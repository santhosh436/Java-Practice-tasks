package com.AnnotationPractice.SpringandSpringbootAnnotations;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringandSpringbootAnnotationsApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringandSpringbootAnnotationsApplication.class, args);
	}

}
